import { Skull } from "lucide-react";

interface Props {
  score: number;
  scoreLabel: string;
  size?: "sm" | "md" | "lg";
  showLabel?: boolean;
}

const labelConfig = {
  highly_haunted: { text: "Highly Haunted", badgeClass: "badge-haunted", icon: "🔴" },
  controversial: { text: "Controversial", badgeClass: "badge-controversial", icon: "🟠" },
  likely_fake: { text: "Likely Fake", badgeClass: "badge-fake", icon: "🟢" },
  unknown: { text: "Unknown", badgeClass: "badge-unknown", icon: "⚪" },
};

export function HauntedScoreBadge({ score, scoreLabel, size = "md", showLabel = true }: Props) {
  const config = labelConfig[scoreLabel as keyof typeof labelConfig] || labelConfig.unknown;

  const sizeClasses = {
    sm: "text-xs px-2 py-0.5 rounded",
    md: "text-sm px-3 py-1 rounded-md",
    lg: "text-base px-4 py-1.5 rounded-lg",
  };

  const iconSize = {
    sm: 10,
    md: 12,
    lg: 14,
  };

  return (
    <div className="flex items-center gap-2">
      <span
        className={`${config.badgeClass} ${sizeClasses[size]} font-ui font-semibold inline-flex items-center gap-1.5 tabular-nums`}
      >
        <Skull size={iconSize[size]} />
        {score}
        {showLabel && <span className="opacity-80">/ 100</span>}
      </span>
      {showLabel && (
        <span className="text-muted-foreground font-ui text-xs">{config.text}</span>
      )}
    </div>
  );
}

export function ScoreRing({ score, scoreLabel }: { score: number; scoreLabel: string }) {
  const config = labelConfig[scoreLabel as keyof typeof labelConfig] || labelConfig.unknown;
  const radius = 28;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  const strokeColor =
    scoreLabel === "highly_haunted"
      ? "oklch(0.52 0.22 25)"
      : scoreLabel === "controversial"
      ? "oklch(0.65 0.18 60)"
      : scoreLabel === "likely_fake"
      ? "oklch(0.35 0.14 145)"
      : "oklch(0.22 0.01 260)";

  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative w-20 h-20">
        <svg className="w-20 h-20 -rotate-90" viewBox="0 0 70 70">
          <circle
            cx="35"
            cy="35"
            r={radius}
            fill="none"
            stroke="oklch(0.14 0.01 260)"
            strokeWidth="6"
          />
          <circle
            cx="35"
            cy="35"
            r={radius}
            fill="none"
            stroke={strokeColor}
            strokeWidth="6"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${strokeColor})`, transition: "stroke-dashoffset 1s ease" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-heading text-lg font-bold text-foreground leading-none">{score}</span>
          <span className="font-ui text-[9px] text-muted-foreground uppercase tracking-wider">score</span>
        </div>
      </div>
      <span className={`${config.badgeClass} text-xs px-2 py-0.5 rounded font-ui font-semibold`}>
        {config.text}
      </span>
    </div>
  );
}
